import json
import math
import random
import threading
import time
from collections import deque
from datetime import datetime, timedelta, timezone
from typing import Optional
from urllib.request import urlopen


class DataFeed:
    def __init__(self, config: dict, logger):
        self.config = config
        self.logger = logger
        self.symbol = str(config.get("symbol", "BTCUSDT")).upper()
        self.symbol_lower = self.symbol.lower()
        self.timeframe = str(config.get("timeframe", "5m"))
        self.data_mode = str(config.get("data_mode", "mock")).lower()
        self.warmup_candles = int(config.get("data", {}).get("warmup_candles", 160))
        self.websocket_reconnect_seconds = int(config.get("data", {}).get("websocket_reconnect_seconds", 5))

        self._current_price = 30000.0
        self._current_volume = 100.0
        self._mock_step = 0
        self._mock_shock = 0.0
        self._mock_timestamp = datetime.now(timezone.utc) - timedelta(minutes=self._timeframe_minutes())

        self._lock = threading.Lock()
        self._closed_candles = deque()
        self._latest_partial = None
        self._ws_started = False

        if self.data_mode == "websocket":
            self._start_websocket()
        else:
            self.logger.info("data feed running in mock mode")

    def bootstrap_candles(self) -> list[dict]:
        start_time = time.time()
        if self.data_mode == "mock":
            candles = [self._generate_mock_candle() for _ in range(self.warmup_candles)]
            duration = time.time() - start_time
            self.logger.info("mock warmup generated | candles=%s | duration=%.3fs", len(candles), duration)
            return candles

        candles = self._fetch_rest_klines(limit=self.warmup_candles)
        duration = time.time() - start_time
        if candles:
            last_close = candles[-1]["close"] if candles else 0
            last_time = candles[-1]["timestamp"] if candles else None
            self.logger.info(
                "rest warmup loaded | candles=%s | last_close=%.4f | last_time=%s | duration=%.3fs",
                len(candles), last_close, last_time, duration
            )
        else:
            self.logger.warning("rest warmup returned no candles | duration=%.3fs", duration)
        return candles

    def get_latest(self) -> Optional[dict]:
        if self.data_mode == "mock":
            return self._generate_mock_candle()

        with self._lock:
            if self._closed_candles:
                return self._closed_candles.popleft()
            if self._latest_partial:
                return dict(self._latest_partial)
        return None

    def _timeframe_minutes(self) -> int:
        mapping = {"1m": 1, "3m": 3, "5m": 5, "15m": 15, "30m": 30, "1h": 60}
        return mapping.get(self.timeframe, 5)

    def _generate_mock_candle(self) -> dict:
        self._mock_step += 1
        if abs(self._mock_shock) < 5 and random.random() < 0.10:
            self._mock_shock += random.choice([1.0, -1.0]) * random.uniform(120.0, 240.0)

        drift = math.sin(self._mock_step / 6.0) * 10.0
        noise = random.gauss(0.0, 18.0)
        impulse = self._mock_shock * 0.22
        self._mock_shock *= 0.80

        open_price = self._current_price
        close_price = max(500.0, open_price + drift + noise + impulse)
        candle_range = max(abs(close_price - open_price), 10.0)
        high = max(open_price, close_price) + random.uniform(2.0, candle_range * 0.8)
        low = min(open_price, close_price) - random.uniform(2.0, candle_range * 0.8)
        volume = abs(close_price - open_price) * random.uniform(1.5, 3.2) + random.uniform(50.0, 180.0)

        self._current_price = close_price
        self._current_volume = volume
        self._mock_timestamp += timedelta(minutes=self._timeframe_minutes())

        return self._build_candle(
            timestamp=self._mock_timestamp,
            open_price=open_price,
            high=high,
            low=low,
            close=close_price,
            volume=volume,
            closed=True,
        )

    def _fetch_rest_klines(self, limit: int) -> list[dict]:
        base_url = self.config.get("binance", {}).get("futures_base_url", "https://fapi.binance.com")
        url = f"{base_url}/fapi/v1/klines?symbol={self.symbol}&interval={self.timeframe}&limit={limit}"
        fetch_start = time.time()
        try:
            self.logger.debug("Fetching REST klines | url=%s | limit=%s", url, limit)
            with urlopen(url, timeout=10) as response:
                payload = json.loads(response.read().decode("utf-8"))
            fetch_duration = time.time() - fetch_start
            
            candles = []
            for item in payload:
                close_time = datetime.fromtimestamp(item[6] / 1000, tz=timezone.utc)
                candles.append(
                    self._build_candle(
                        timestamp=close_time,
                        open_price=float(item[1]),
                        high=float(item[2]),
                        low=float(item[3]),
                        close=float(item[4]),
                        volume=float(item[5]),
                        closed=True,
                    )
                )
            if candles:
                last = candles[-1]
                self._current_price = last["close"]
                self._current_volume = last["volume"]
                self.logger.info(
                    "REST klines fetched successfully | count=%s | fetch_time=%.3fs | last_price=%.4f",
                    len(candles), fetch_duration, last["close"]
                )
            else:
                self.logger.warning("REST klines returned empty result | fetch_time=%.3fs", fetch_duration)
            return candles
        except Exception as exc:
            fetch_duration = time.time() - fetch_start
            self.logger.error(
                "Failed to fetch REST klines | error=%s | duration=%.3fs | falling back to mock",
                str(exc), fetch_duration
            )
            self.data_mode = "mock"
            return [self._generate_mock_candle() for _ in range(limit)]

    def _start_websocket(self) -> None:
        if self._ws_started:
            return
        self._ws_started = True
        
        self.logger.info("Starting websocket connection | symbol=%s | timeframe=%s", self.symbol, self.timeframe)

        def runner() -> None:
            import websocket
            
            url = f"wss://fstream.binance.com/ws/{self.symbol_lower}@kline_{self.timeframe}"
            reconnect_attempts = 0
            last_success_time = None
            
            while True:
                ws_start_time = time.time()
                try:
                    self.logger.debug("Creating websocket connection | url=%s | attempt=%s", url, reconnect_attempts + 1)
                    ws = websocket.WebSocketApp(
                        url,
                        on_message=self._on_message,
                        on_error=self._on_error,
                        on_close=self._on_close,
                        on_open=self._on_open,
                    )
                    ws.run_forever(ping_interval=20, ping_timeout=10)
                except Exception as exc:
                    reconnect_attempts += 1
                    duration = time.time() - ws_start_time
                    self.logger.error(
                        "WEBSOCKET ERROR | attempt=%s | error=%s | duration=%.3fs | reconnecting in %ds",
                        reconnect_attempts, str(exc), duration, self.websocket_reconnect_seconds
                    )
                    self.logger.debug(f"Websocket stack trace:\n{traceback.format_exc()}")
                else:
                    if last_success_time:
                        reconnect_attempts += 1
                        self.logger.warning(
                            "WEBSOCKET DISCONNECTED | attempt=%s | uptime=%.3fs | reconnecting...",
                            reconnect_attempts, time.time() - last_success_time
                        )
                    else:
                        last_success_time = time.time()
                        self.logger.info("WEBSOCKET CONNECTION ESTABLISHED | attempt=%s", reconnect_attempts + 1)
                time.sleep(self.websocket_reconnect_seconds)

        thread = threading.Thread(target=runner, name="qq-websocket", daemon=True)
        thread.start()

    def _on_message(self, _ws, message: str) -> None:
        import traceback as tb
        try:
            data = json.loads(message)
            kline = data["k"]
            candle = self._build_candle(
                timestamp=datetime.fromtimestamp(kline[6] / 1000, tz=timezone.utc),
                open_price=float(kline["o"]),
                high=float(kline["h"]),
                low=float(kline["l"]),
                close=float(kline["c"]),
                volume=float(kline["v"]),
                closed=bool(kline["x"]),
            )
            with self._lock:
                self._latest_partial = candle
                if candle["closed"]:
                    self._closed_candles.append(candle)
                    self.logger.debug(
                        "WEBSOCKET CANDLE CLOSED | symbol=%s | close=%.4f | volume=%.2f | time=%s",
                        self.symbol, candle["close"], candle["volume"], candle["timestamp"]
                    )
            self._current_price = candle["close"]
            self._current_volume = candle["volume"]
        except Exception as exc:
            self.logger.error("Failed to parse websocket message | error=%s", str(exc))
            self.logger.debug(f"Parse error stack trace:\n{tb.format_exc()}")

    def _on_error(self, _ws, error) -> None:
        self.logger.error("WEBSOCKET ERROR EVENT | error=%s", str(error))

    def _on_close(self, _ws, status_code, message) -> None:
        self.logger.warning(
            "WEBSOCKET CLOSED | symbol=%s | timeframe=%s | status_code=%s | message=%s",
            self.symbol, self.timeframe, status_code, message
        )

    def _on_open(self, _ws) -> None:
        connect_time = datetime.now(timezone.utc).isoformat()
        self.logger.info(
            "WEBSOCKET CONNECTED | symbol=%s | timeframe=%s | timestamp=%s",
            self.symbol, self.timeframe, connect_time
        )

    def _build_candle(
        self,
        timestamp: datetime,
        open_price: float,
        high: float,
        low: float,
        close: float,
        volume: float,
        closed: bool,
    ) -> dict:
        return {
            "symbol": self.symbol,
            "timestamp": timestamp,
            "open": float(open_price),
            "high": float(high),
            "low": float(low),
            "close": float(close),
            "price": float(close),
            "volume": float(volume),
            "closed": bool(closed),
        }
