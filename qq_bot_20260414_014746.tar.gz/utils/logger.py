import logging
import sys
import traceback
from datetime import datetime
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from pathlib import Path


def setup_logging(config: dict) -> None:
    logging_cfg = config.get("logging", {})
    level_name = str(logging_cfg.get("level", "INFO")).upper()
    level = getattr(logging, level_name, logging.INFO)
    file_path = Path(logging_cfg.get("file_path", "logs/bot.log"))
    file_path.parent.mkdir(parents=True, exist_ok=True)
    
    error_log_path = file_path.parent / "error.log"
    detailed_log_path = file_path.parent / "detailed.log"

    standard_formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    
    detailed_formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(name)s | %(module)s:%(lineno)d | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(standard_formatter)
    stream_handler.setLevel(level)

    file_handler = RotatingFileHandler(
        file_path,
        maxBytes=5_000_000,
        backupCount=10,
        encoding="utf-8",
    )
    file_handler.setFormatter(standard_formatter)
    file_handler.setLevel(level)
    
    detailed_handler = RotatingFileHandler(
        detailed_log_path,
        maxBytes=10_000_000,
        backupCount=15,
        encoding="utf-8",
    )
    detailed_handler.setFormatter(detailed_formatter)
    detailed_handler.setLevel(logging.DEBUG)
    
    error_handler = RotatingFileHandler(
        error_log_path,
        maxBytes=5_000_000,
        backupCount=10,
        encoding="utf-8",
    )
    error_handler.setFormatter(detailed_formatter)
    error_handler.setLevel(logging.ERROR)

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(level)
    root.addHandler(stream_handler)
    root.addHandler(file_handler)
    root.addHandler(detailed_handler)
    root.addHandler(error_handler)
    
    logging.captureWarnings(True)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def log_exception(logger: logging.Logger, message: str, exc: Exception) -> None:
    """记录异常详情，包括堆栈跟踪"""
    logger.error(f"{message} | exception_type={type(exc).__name__} | error={str(exc)}")
    logger.debug(f"Stack trace:\n{traceback.format_exc()}")


def log_system_status(logger: logging.Logger, status_type: str, details: dict) -> None:
    """记录系统状态信息"""
    timestamp = datetime.now().isoformat()
    logger.info(f"[SYSTEM_STATUS] {status_type} | timestamp={timestamp} | {format_dict(details)}")


def format_dict(d: dict, prefix: str = "") -> str:
    """格式化字典为日志字符串"""
    items = []
    for key, value in d.items():
        if isinstance(value, dict):
            items.append(format_dict(value, f"{prefix}{key}."))
        else:
            items.append(f"{prefix}{key}={value}")
    return " | ".join(items)


class DiagnosticContext:
    """上下文管理器，用于记录代码块的执行情况和性能"""
    
    def __init__(self, logger: logging.Logger, operation: str, extra_data: dict = None):
        self.logger = logger
        self.operation = operation
        self.extra_data = extra_data or {}
        self.start_time = None
        
    def __enter__(self):
        self.start_time = datetime.now()
        self.logger.debug(f"[DIAGNOSTIC] Starting operation: {self.operation} | {format_dict(self.extra_data)}")
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = (datetime.now() - self.start_time).total_seconds()
        if exc_type is not None:
            self.logger.error(
                f"[DIAGNOSTIC] Operation failed: {self.operation} | "
                f"duration={duration:.3f}s | exception={type(exc_val).__name__}: {str(exc_val)}"
            )
            self.logger.debug(f"Stack trace:\n{traceback.format_exc()}")
        else:
            self.logger.debug(
                f"[DIAGNOSTIC] Operation completed: {self.operation} | duration={duration:.3f}s"
            )
        return False
