import os
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

import yaml

from core.data_feed import DataFeed
from core.execution import ExecutionEngine
from core.exchange import ExchangeClient
from core.order_manager import OrderManager
from core.risk_manager import RiskManager
from core.signal_engine import SignalEngine
from core.trade_logger import TradeLogger
from utils.logger import get_logger, setup_logging, log_system_status, DiagnosticContext


DEFAULT_CONFIG_PATH = Path(__file__).with_name("config.yaml")


def load_config() -> dict:
    config_path = Path(os.environ.get("QQ_CONFIG_PATH", DEFAULT_CONFIG_PATH))
    with DiagnosticContext(get_logger("init"), "load_config", {"config_path": str(config_path)}):
        with config_path.open("r", encoding="utf-8") as handle:
            config = yaml.safe_load(handle) or {}
        config["_config_path"] = str(config_path)
        return config


def build_runtime(config: dict) -> dict:
    runtime = dict(config.get("runtime", {}))
    env_max_loops = os.environ.get("QQ_MAX_LOOPS")
    env_loop_interval = os.environ.get("QQ_LOOP_INTERVAL_SECONDS")
    env_heartbeat_interval = os.environ.get("QQ_HEARTBEAT_INTERVAL_SECONDS")
    if env_max_loops is not None:
        runtime["max_loops"] = int(env_max_loops)
    if env_loop_interval is not None:
        runtime["loop_interval_seconds"] = float(env_loop_interval)
    if env_heartbeat_interval is not None:
        runtime["heartbeat_interval_seconds"] = float(env_heartbeat_interval)
    runtime.setdefault("loop_interval_seconds", 1.0)
    runtime.setdefault("heartbeat_interval_seconds", 30)
    runtime.setdefault("max_loops", 0)
    return runtime


def warmup_signal_engine(signal_engine: SignalEngine, candles: list[dict]) -> None:
    if not candles:
        return
    signal_engine.seed_history(candles)


class TradingApplication:
    def __init__(self, config: dict):
        self.config = config
        self.runtime = build_runtime(config)
        
        startup_time = datetime.now(timezone.utc).isoformat()
        python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        
        setup_logging(config)
        self.logger = get_logger("app")
        
        self.logger.info("=" * 80)
        self.logger.info("TRADING BOT STARTUP INITIALIZATION")
        self.logger.info("=" * 80)
        self.logger.info(f"Startup timestamp: {startup_time}")
        self.logger.info(f"Python version: {python_version}")
        self.logger.info(f"Config file: {config.get('_config_path', 'unknown')}")
        self.logger.info(f"Mode: {config.get('mode')} | Data mode: {config.get('data_mode')}")
        self.logger.info(f"Symbol: {config.get('symbol')} | Timeframe: {config.get('timeframe')}")
        
        log_system_status(
            self.logger, 
            "INIT_START",
            {
                "mode": config.get("mode"),
                "data_mode": config.get("data_mode"),
                "symbol": config.get("symbol"),
                "timeframe": config.get("timeframe"),
                "python_version": python_version,
                "startup_time": startup_time
            }
        )

        with DiagnosticContext(self.logger, "init_components", {}):
            self.logger.info("Initializing trade logger...")
            self.trade_logger = TradeLogger(config)
            self.logger.info("Trade logger initialized | file=%s", self.trade_logger.file_path)
            
            self.logger.info("Initializing order manager...")
            self.order_manager = OrderManager(config)
            self.logger.info("Order manager initialized")
            
            self.logger.info("Initializing risk manager...")
            self.risk_manager = RiskManager(config, self.logger)
            risk_config = config.get("risk", {})
            self.logger.info(
                "Risk manager initialized | starting_balance=%s | risk_per_trade=%s%% | leverage=%s",
                risk_config.get("starting_balance_usdt"),
                risk_config.get("risk_per_trade", 0) * 100,
                risk_config.get("leverage", 1)
            )
            
            self.logger.info("Initializing signal engine...")
            self.signal_engine = SignalEngine(config, self.logger)
            self.logger.info("Signal engine initialized | strategy=%s", config.get("strategy", {}).get("lookback", "unknown"))
            
            self.logger.info("Initializing data feed...")
            self.data_feed = DataFeed(config, self.logger)
            self.logger.info("Data feed initialized | warmup_candles=%s", config.get("data", {}).get("warmup_candles", 0))
            
            self.logger.info("Initializing exchange client...")
            self.exchange = ExchangeClient(config, self.logger)
            exchange_enabled = self.exchange.is_enabled()
            self.logger.info(
                "Exchange client initialized | enabled=%s | api_key_configured=%s",
                exchange_enabled,
                "yes" if config.get("binance", {}).get("api_key") else "no"
            )
            
            self.logger.info("Initializing execution engine...")
            self.execution = ExecutionEngine(
                config=config,
                order_manager=self.order_manager,
                exchange=self.exchange,
                logger=self.logger,
            )
            self.logger.info("Execution engine initialized")

        with DiagnosticContext(self.logger, "bootstrap_data", {}):
            self.logger.info("Loading bootstrap candles...")
            bootstrap_candles = self.data_feed.bootstrap_candles()
            warmup_signal_engine(self.signal_engine, bootstrap_candles)
            self.logger.info(
                "Bootstrap completed | candles_loaded=%s | signal_engine_candles=%s",
                len(bootstrap_candles) if bootstrap_candles else 0,
                self.signal_engine.candle_count
            )

        if self.exchange.is_enabled():
            with DiagnosticContext(self.logger, "exchange_health_check", {}):
                self.logger.info("Performing exchange health check...")
                ping_result = self.exchange.ping()
                self.logger.info("Exchange ping result: %s", ping_result)
                
                live_snapshot = self.exchange.fetch_position_snapshot()
                if live_snapshot:
                    live_snapshot.update(self.exchange.fetch_protection_snapshot())
                    self.order_manager.restore_live_position(live_snapshot)
                    self.logger.warning(
                        "LIVE POSITION RESTORED FROM EXCHANGE | symbol=%s | side=%s | qty=%s",
                        live_snapshot.get("symbol"),
                        live_snapshot.get("side"),
                        live_snapshot.get("quantity")
                    )
                    log_system_status(
                        self.logger,
                        "LIVE_POSITION_RESTORED",
                        {
                            "symbol": live_snapshot.get("symbol"),
                            "side": live_snapshot.get("side"),
                            "quantity": live_snapshot.get("quantity"),
                            "entry_price": live_snapshot.get("entry_price")
                        }
                    )
        
        log_system_status(
            self.logger,
            "INIT_COMPLETE",
            {
                "warmup_candles": self.signal_engine.candle_count,
                "exchange_enabled": self.exchange.is_enabled(),
                "position_exists": self.order_manager.has_position(),
                "initialization_status": "success"
            }
        )
        self.logger.info("=" * 80)

    def run(self) -> None:
        heartbeat_interval = self.runtime["heartbeat_interval_seconds"]
        loop_interval = self.runtime["loop_interval_seconds"]
        max_loops = self.runtime["max_loops"]
        loop_count = 0
        last_heartbeat = time.time()
        last_guard_check = 0.0
        
        self.logger.info("Runtime configuration | loop_interval=%ss | heartbeat_interval=%ss | max_loops=%s", 
                        loop_interval, heartbeat_interval, max_loops)
        self.logger.info("Signal engine ready | warm_candles=%s", self.signal_engine.candle_count)
        
        loop_times = []
        error_count = 0
        
        while True:
            loop_started = time.time()
            loop_iteration = loop_count + 1
            
            try:
                with DiagnosticContext(self.logger, f"loop_{loop_iteration}", {"iteration": loop_iteration}):
                    market = self.data_feed.get_latest()
                    if not market:
                        self.logger.debug("No market data available, waiting...")
                        time.sleep(loop_interval)
                        continue

                    closed_trade = self.order_manager.update_market(market)
                    if closed_trade:
                        with DiagnosticContext(self.logger, "trade_closed", {
                            "trade_id": closed_trade.get("trade_id"),
                            "exit_reason": closed_trade.get("exit_reason")
                        }):
                            self.trade_logger.log_trade(closed_trade)
                            self.risk_manager.on_trade_closed(closed_trade)
                            self.signal_engine.on_trade_closed(closed_trade)
                            pnl = closed_trade.get("pnl", 0)
                            pnl_status = "WIN" if pnl > 0 else "LOSS"
                            self.logger.info(
                                "TRADE CLOSED | id=%s | reason=%s | pnl=%.4f USDT | status=%s",
                                closed_trade["trade_id"],
                                closed_trade["exit_reason"],
                                pnl,
                                pnl_status
                            )
                            log_system_status(
                                self.logger,
                                "TRADE_CLOSED",
                                {
                                    "trade_id": closed_trade.get("trade_id"),
                                    "symbol": closed_trade.get("symbol"),
                                    "exit_reason": closed_trade.get("exit_reason"),
                                    "pnl": pnl,
                                    "pnl_status": pnl_status,
                                    "score": closed_trade.get("score")
                                }
                            )

                    if self.exchange.is_enabled() and self.order_manager.has_position():
                        guard_interval = self.config.get("execution", {}).get("guard_check_interval_seconds", 5)
                        now_ts = time.time()
                        if now_ts - last_guard_check >= guard_interval:
                            self.logger.debug("Performing guard check for live protection...")
                            self.execution.ensure_live_protection()
                            last_guard_check = now_ts

                    if market.get("closed"):
                        signal = self.signal_engine.on_candle(
                            market,
                            has_position=self.order_manager.has_position(),
                        )

                        if signal["action"] == "SHORT":
                            self.logger.debug(
                                "Trading signal detected | action=%s | score=%s | zscore=%.4f",
                                signal["action"],
                                signal.get("score"),
                                signal.get("zscore", 0)
                            )
                            allowed, reason = self.risk_manager.can_open_new_trade(market["timestamp"])
                            if not allowed:
                                self.logger.info(
                                    "SIGNAL REJECTED by risk manager | reason=%s | score=%s",
                                    reason,
                                    signal.get("score")
                                )
                            elif not self.order_manager.can_open():
                                self.logger.info("SIGNAL REJECTED | position already exists")
                            else:
                                with DiagnosticContext(self.logger, "open_position", {
                                    "signal_score": signal.get("score"),
                                    "signal_zscore": signal.get("zscore")
                                }):
                                    position_plan = self.risk_manager.calculate_position(signal)
                                    self.logger.info(
                                        "Position plan calculated | notional=%s | stop_loss=%s | take_profit=%s",
                                        position_plan.get("notional"),
                                        position_plan.get("stop_price"),
                                        position_plan.get("take_profit_price")
                                    )
                                    execution_result = self.execution.open_short(position_plan, signal, market)
                                    if execution_result.get("accepted"):
                                        self.order_manager.open_position(execution_result, signal, market)
                                        self.signal_engine.on_position_opened()
                                        self.logger.info(
                                            "POSITION OPENED | mode=%s | qty=%.6f | entry=%.4f | notional=%.2f",
                                            execution_result["mode"],
                                            execution_result["quantity"],
                                            execution_result["entry_price"],
                                            execution_result.get("notional", 0)
                                        )
                                        log_system_status(
                                            self.logger,
                                            "POSITION_OPENED",
                                            {
                                                "mode": execution_result["mode"],
                                                "symbol": execution_result.get("symbol"),
                                                "quantity": execution_result["quantity"],
                                                "entry_price": execution_result["entry_price"],
                                                "notional": execution_result.get("notional"),
                                                "score": signal.get("score"),
                                                "zscore": signal.get("zscore")
                                            }
                                        )
                                    else:
                                        rejection_reason = execution_result.get("reason", "unknown")
                                        self.logger.warning(
                                            "EXECUTION REJECTED | reason=%s | slippage_check=%s",
                                            rejection_reason,
                                            execution_result.get("slippage_ok", "N/A")
                                        )

                    if time.time() - last_heartbeat >= heartbeat_interval:
                        balance = self.risk_manager.balance
                        price = market.get("close", market.get("price", 0.0))
                        position_status = "ACTIVE" if self.order_manager.has_position() else "IDLE"
                        self.logger.info(
                            "HEARTBEAT | price=%.4f | position=%s | balance=%.4f USDT | state=%s | consecutive_losses=%s",
                            price,
                            position_status,
                            balance,
                            self.signal_engine.state,
                            self.risk_manager.consecutive_losses
                        )
                        last_heartbeat = time.time()

                    loop_count += 1
                    if max_loops and loop_count >= max_loops:
                        self.logger.info("MAX LOOPS REACHED | loops_completed=%s | exiting gracefully", loop_count)
                        break

                    elapsed = time.time() - loop_started
                    loop_times.append(elapsed)
                    avg_loop_time = sum(loop_times[-10:]) / min(len(loop_times), 10)
                    
                    if elapsed > loop_interval:
                        self.logger.warning(
                            "Loop execution slow | elapsed=%.3fs | interval=%.3fs | avg_last_10=%.3fs",
                            elapsed, loop_interval, avg_loop_time
                        )
                    
                    sleep_time = max(0.0, loop_interval - elapsed)
                    if sleep_time > 0:
                        time.sleep(sleep_time)

            except KeyboardInterrupt:
                self.logger.warning("MANUAL STOP RECEIVED | shutting down...")
                break
            except Exception as exc:
                error_count += 1
                self.logger.error(
                    "RUNTIME ERROR | iteration=%s | error_count=%s | exception_type=%s | error=%s",
                    loop_iteration, error_count, type(exc).__name__, str(exc)
                )
                self.logger.debug(f"Stack trace:\n{traceback.format_exc()}")
                log_system_status(
                    self.logger,
                    "RUNTIME_ERROR",
                    {
                        "iteration": loop_iteration,
                        "error_count": error_count,
                        "exception_type": type(exc).__name__,
                        "error_message": str(exc)
                    }
                )
                if error_count > 10:
                    self.logger.critical("Too many consecutive errors, shutting down...")
                    break
                time.sleep(3)

        total_runtime = time.time() - (time.time() - sum(loop_times)) if loop_times else 0
        avg_loop_time = sum(loop_times) / len(loop_times) if loop_times else 0
        self.logger.info("=" * 80)
        self.logger.info("BOT SHUTDOWN | total_loops=%s | avg_loop_time=%.3fs | total_errors=%s", 
                        loop_count, avg_loop_time, error_count)
        self.logger.info("Shutdown timestamp: %s", datetime.now(timezone.utc).isoformat())
        self.logger.info("=" * 80)


def main() -> None:
    config = load_config()
    app = TradingApplication(config)
    app.run()


if __name__ == "__main__":
    main()
